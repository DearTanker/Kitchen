import os
a='/www/backup/database/fdsa_20190808_034550.sql.gz'
print(os.path.exists(a))