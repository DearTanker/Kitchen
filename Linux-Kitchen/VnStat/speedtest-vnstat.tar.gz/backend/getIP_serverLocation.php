<?php

$serverLoc = '22.2783,114.1747';
